var face=1;

var show = function ok(x) {
  $('#cube').attr('class', 'show'+$x);
  
};

var timer=setInterval("show()", 500);